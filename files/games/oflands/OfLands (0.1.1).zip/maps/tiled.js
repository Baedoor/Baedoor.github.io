/* Of Lands' Tiled extension, allowing for Tiled maps to output .olm files */
// See `Tiled.md` file for actual guide on how to work with Tiled to create
// proper Of Lands maps

var olmMapFormat = {
    name: "Of Lands Map format",
    extension: "olm",

    outputFiles: function(map, fileName) {
        const baseName = fileName.substring(0, fileName.lastIndexOf("."));
        return [baseName + "olm", baseName + "olf", baseName + "olr", baseName + "oldata"];
    },

    write: function(map, fileName) {
        // base data
        const baseName        = fileName.substring(0, fileName.lastIndexOf("."));
        const baseDir         = fileName.substring(0, fileName.lastIndexOf("/"));
        const pureName        = fileName.substring(fileName.lastIndexOf("/") + 1, fileName.lastIndexOf("."))
        var tilesets          = map.tilesets;
        var tilesets_dict     = tilesets.reduce(function(dict, x) { // it does convert list to dict actually lol
                                    dict[x.name] = x;
                                    return dict;
                                }, {});
        var layers            = map.layers;
        var layers_dict       = layers.reduce(function(dict, x) { // it does convert list to dict actually lol
                                    dict[x.name] = x;
                                    return dict;
        }, {});
        var map_properties    = map.properties();
        var faction_count     = "factions_count" in map_properties ? map.property("factions_count") : 0;
        // TODO: make faction tileset optional!!!!!!
        var tileset_terrain   = tilesets_dict["Landscape"].imageFileName.match(String.raw`(\w*.png)`);  // regexed only file name, without path
        var tileset_locations = tilesets_dict["Locations"].imageFileName.match(String.raw`(\w*.png)`);  // regexed only file name, without path
        var tileset_resources = tilesets_dict["Resources"].imageFileName.match(String.raw`(\w*.png)`);  // regexed only file name, without path
        var tileset_factions  = tilesets_dict["Factions"].imageFileName.match(String.raw`(\w*.png)`);   // regexed only file name, without path
        var tileset_system    = tilesets_dict["System"].imageFileName.match(String.raw`(\w*.png)`);     // regexed only file name, without path
        var data_terrain      = tileset_terrain[0].replace(".png", ".oldata");           // sets .oldata to have the same name as tileset image
        var data_locations    = tileset_locations[0].replace(".png", ".oldata");         // sets .oldata to have the same name as tileset image

        // factions
        if (faction_count > 0 && "Factions" in tilesets_dict) {
            var olf           = ""; // output file string
            var faction_tiles = tilesets_dict["Factions"].tiles;

            for (let faction_ix = 0; faction_ix < faction_count; faction_ix++) {
                var faction_tile = faction_tiles[faction_ix];
                var faction_prop = faction_tile.properties();
                olf = olf + `[kingdom.${faction_ix + 1}]`                          + "\n"; // header
                if ("name" in faction_prop) {
                    olf = olf + "name = " + String.raw`"${faction_tile.property('name')}"` + "\n";
                } else {
                    olf = olf + "name = " + String.raw`""` + "\n"; // put empty 'name' to avoid .toml parsing issues with empty category
                }
                if ("start_coords" in faction_prop) {
                    olf = olf + "start_coordinates = " + "[" + faction_tile.property("start_coords") + "]\n";
                }
                if ("description" in faction_prop) {
                    olf = olf + "description = " + String.raw`'''` + faction_tile.property("description") + String.raw`'''` + "\n";
                }
            }
//            for (const kingdom_nb of Array(999).keys()) { // checks for kingdom registry, needs to have consecutive numbers
//                var kingdom_var = `kingdom_${kingdom_nb + 1}_name`
//                if (kingdom_var in map.properties()) {
//                    olf = olf + `[kingdom.${kingdom_nb + 1}]`                          + "\n"; // header
//                    olf = olf + "name = " + String.raw`"${map.property(kingdom_var)}"` + "\n";
//                } else {
//                    break; // breaks when finds the gap
//                }
//            }
            // faction check is done on top, so there's no need to check for it again here
            var settlements = tilesets_dict["Factions"].tiles;
            for (const settlement of settlements) {
                if (settlement.id >= faction_count) { // skips faction registry
                    // checks if tile has data (required & optional)
                    var settlement_properties = settlement.properties();
                    if (("kingdom" in settlement_properties) && ("tier" in settlement_properties) && ("name" in settlement_properties)) {
                        // checks if tile has properly set required data
                        if ((settlement.property("kingdom") != 0) && (settlement.property("tier") != "")) {
                            olf = olf + `[settlement.${settlement.id}]`                             + "\n";
                            olf = olf + "kingdom = " + settlement.property("kingdom")               + "\n";
                            olf = olf + "name    = " + String.raw`"${settlement.property('name')}"` + "\n";
                            olf = olf + "tier    = " + String.raw`"${settlement.property('tier')}"` + "\n";
                            // lists resources if provided
                            if ("tile_resources" in settlement_properties) {
                                // PARSER -- may make sense to move it to `func` eventually for wider use
                                var res_dict  = {};
                                var res_lines = settlement.property("tile_resources").split("\n");
                                var coords    = []; // coords pointer
                                var cord_dict = {}; // coords-specific dict (nested into `res_dict`)
                                for (var ln = 0; ln < res_lines.length; ++ln) {
                                    if (res_lines[ln].startsWith("[") && res_lines[ln].endsWith("]")) {
                                        if (coords.length == 2) { // each new coords round resets the dict
                                            cord_dict = {}
                                        }
                                        var coords_clean = res_lines[ln].replace(" ", "").replace("[", "").replace("]", "");
                                        var coords_spl   = coords_clean.split(",");
                                        if (coords_spl.length == 2) { // correct count
                                            coords = coords_spl;
                                        }
                                        continue; // proceeds to next line
                                    } // else:
                                    if (coords.length == 2) { // analyses line only if provided with coords pointer
                                        var key_val = res_lines[ln].split(":");
                                        // ^ line w/o ":" has len==1 and is treated as comment (ignored)
                                        if (key_val.length == 2) { // correct count
                                            var key_prs = key_val[0].split("|"); // parses key string
                                            var key_cln = key_prs[0]; // clean key
                                            var key_cmt = (key_prs.length == 2) ? ` # ${key_prs[1].trim()}` // comment
                                                                                : ""
                                            // registering the item/count
                                            cord_dict[key_cln.trim()] = `"${key_val[1].trim()}"${key_cmt}`;
                                            // overwrites with increasingly bigger dict
                                            res_dict[`${coords[0]}__${coords[1]}`] = cord_dict;
                                        }
                                    }
                                }
                                for (const [coo, items] of Object.entries(res_dict)) {
                                    if (Object.keys(items).length > 0) { // if coords have any resources listed
                                        olf = olf + `[settlement.${settlement.id}.resources.${coo}]` + "\n";
                                        for (const [itm, amount] of Object.entries(items)) {
                                            olf = olf + `${itm} = ${amount}` + "\n";
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if ("Settlements" in layers_dict) {
                var layer = layers_dict["Settlements"]; // terrain
                if (layer.isTileLayer) {
                    olf = olf + "[map]"           + "\n";
                    olf = olf + "settlements = [" + "\n";
                    for (var y = 0; y < layer.height; ++y) {
                        olf = olf + "    [";
                        for (var x = 0; x < layer.width; ++x)
                            olf = olf + layer.cellAt(x, y).tileId + ",";
                        olf = olf + "],\n";
                    }
                }
                olf = olf + "]\n";
            }
            if (olf.length > 0) {
                var factionFile = new TextFile(baseName + ".olf", TextFile.WriteOnly); // writes .olf named samely as map
                factionFile.write(olf);
                factionFile.commit();
            }
        }

        // resources
        if ("Resources" in tilesets_dict) { // todo: make it required?
            var olr            = ""; // output file string
            var resource_tiles = tilesets_dict["Resources"].tiles;

            for (let res_ix = 0; res_ix < resource_tiles.length; res_ix++) {
                var res_tile = resource_tiles[res_ix];
                var res_prop = res_tile.properties();
                if (("name" in res_prop) && ("weight" in res_prop)) { // REQUIRED FOR REGISTRATION
                    if (res_tile.property("name") != "") {
                        // checks if tile has required keys and that name is not empty
//                        function multireplace(og_str, replace_array, replace_char) {
//                            for (array_char in replace_array) {
//                                og_str = og_str.replace(array_char, replace_char);
//                            }
//                            return og_str;
//                        }

//                        var res_id = ("id" in res_prop) ? res_tile.property("id") // if "id" field exists, it is used
//                                                        : multireplace(
//                                                            res_tile.property("name"), // og string
//                                                            [" ", ".", ",", ";"],      // things to be replaced
//                                                             "_").toLowerCase();       // replacement, and getting ID unified
                        // optional values
                        var res_qual = ("quality" in res_prop) ? res_tile.property("quality") : 0;
                        var res_fuel = ("fuel" in res_prop)    ? res_tile.property("fuel")    : 0;
                        var res_wgt  = ("weight" in res_prop)  ? res_tile.property("weight")  : 1;

                        olr = olr + `[resource.${res_ix}]`                                    + "\n";
                        olr = olr + "name    = " + String.raw`"${res_tile.property('name')}"` + "\n";
                        olr = olr + "index   = " + res_ix                                     + "\n";
                        olr = olr + "quality = " + res_qual                                   + "\n";
                        olr = olr + "fuel    = " + res_fuel                                   + "\n";
                        olr = olr + "weight  = " + res_wgt                                    + "\n";
                    }
                }
            }

            if (olr.length > 0) {
                var resourceFile = new TextFile(baseName + ".olr", TextFile.WriteOnly); // writes .olr named samely as map
                resourceFile.write(olr);
                resourceFile.commit();
            }
        }

        // .olm file contents
        var out = "";
        if ("start_coords" in map_properties) { // optional
            out = out + "start_coordinates = " + "[" + map.property("start_coords") + "]\n";
        }
        if ("start_date" in map_properties) { // optional
            out = out + "start_date        = " + "[" + map.property("start_date") + "]\n";
        }
        if (olf.length > 0) { // if kingdoms are registered
            out = out + "factions          = " + String.raw`"${pureName}.olf"` + "\n";
        }
        out = out + "tileset_terrain   = " + String.raw`"${tileset_terrain[0]}"` + "\n";   // for some reason `match` yields two same entries
        out = out + "tileset_locations = " + String.raw`"${tileset_locations[0]}"` + "\n"; // for some reason `match` yields two same entries
        out = out + "tileset_resources = " + String.raw`"${tileset_resources[0]}"` + "\n"; // for some reason `match` yields two same entries
        out = out + "tileset_factions  = " + String.raw`"${tileset_factions[0]}"` + "\n";  // for some reason `match` yields two same entries
        out = out + "tileset_system    = " + String.raw`"${tileset_system[0]}"` + "\n";    // for some reason `match` yields two same entries
        out = out + "data_terrain      = " + String.raw`"${data_terrain}"`   + "\n";
        out = out + "data_resources    = " + String.raw`"${pureName}.olr"`   + "\n";
        out = out + "data_locations    = " + String.raw`"${data_locations}"` + "\n";
        out = out + "terrain = [" + "\n";

        var layer = layers_dict["Landscape"]; // terrain
        if (layer.isTileLayer) {
            for (var y = 0; y < layer.height; ++y) {
                out = out + "    [";
                for (var x = 0; x < layer.width; ++x) {
                    out = out + layer.cellAt(x, y).tileId + ",";
                }
                out = out + "],\n";
            }
        }

        out = out + "]\n";
        out = out + "locations = [" + "\n";

        var layer = layers_dict["Locations"]; // locations
        if (layer.isTileLayer) {
            for (var y = 0; y < layer.height; ++y) {
                out = out + "    [";
                for (var x = 0; x < layer.width; ++x) {
                    out = out + layer.cellAt(x, y).tileId + ",";
                }
                out = out + "],\n";
            }
        }

        if ("Roads" in layers_dict) { // optionals
            out = out + "]\n";
            out = out + "roads = [" + "\n";

            var layer = layers_dict["Roads"]; // roads
            if (layer.isTileLayer) {
                for (var y = 0; y < layer.height; ++y) {
                    out = out + "    [";
                    for (var x = 0; x < layer.width; ++x) {
                        var tile_id = layer.cellAt(x, y).tileId;
                        if (tile_id < 3) { // safeguard for map to never go above allowed -1..2 index
                            out = out + tile_id + ",";
                        } else {
                            out = out + -1 + ",";
                        }
                    }
                    out = out + "],\n";
                }
            }
        }

        out = out + "]";

        // the main .olm file
        var olmFile = new TextFile(baseName + ".olm", TextFile.WriteOnly);
        olmFile.write(out);
        olmFile.commit();

        // location .oldata parsing
        var locdata = "";
        for (var i = 0; i < tilesets_dict["Locations"].tiles.length; ++i) {
            var tile      = tilesets_dict["Locations"].tiles[i];
            var tile_data = tile.properties();

            if (("name" in tile_data) && ("bcond" in tile_data)) { // REQUIRED FOR REGISTRATION
                // optional values
                var loc_storage = ("storage_size" in tile_data) ? tile.property("storage_size") : 0;
                // required values

                locdata = locdata + `[tile.${tile.id}]`                                         + "\n";
                locdata = locdata + "name         = " + String.raw`"${tile.property('name')}"`  + "\n";
                locdata = locdata + "bcond        = " + String.raw`"${tile.property('bcond')}"` + "\n";
                locdata = locdata + "storage_size = " + loc_storage                             + "\n";

                if (loc_storage > 0 && ("storage" in tile_data)) {
                    var res_dict = {};                                   // resources dict (ID / value)
                    var stlines  = tile.property("storage").split("\n"); // lines
                    for (var line = 0; line < stlines.length; ++line) {
                        var stcont = stlines[line].split(":"); // separates ID from value
                        // ^ line w/o ":" has len==1 and is treated as comment (ignored)
                        if (stcont.length == 2) {
                            var key = stcont[0].split("|")[0].trim(); // ID
                            var val = stcont[1].trim();               // value
                            res_dict[key] = val;
                        }
                    }
                    // tiled.log(`Res_dict length of resource: ${tile.property('name')}: ${res_dict.length}`);
                    if (Object.keys(res_dict).length > 0) { // if any resource is added
                        locdata = locdata + `[tile.${tile.id}.storage]` + "\n";
                        for (const [k, v] of Object.entries(res_dict)) {
                            locdata = locdata + `${k} = "${v}"` + "\n";
                        }
                    }
                }
            }
        }

        // .oldata for locations
        if (locdata.length > 0) { // skips if no properties are set (= user wants to make .oldata manually)
            var locdataFile = new TextFile(baseDir + "/../tilesets/" + data_locations, TextFile.WriteOnly); // writes .oldata in directory of tileset image
            locdataFile.write(locdata);
            locdataFile.commit();
        }

        // terrain .oldata parsing
        var landdata = "";
        for (var i = 0; i < tilesets_dict["Landscape"].tiles.length; ++i) {
            var tile      = tilesets_dict["Landscape"].tiles[i];
            var tile_data = tile.properties();

            if (Object.keys(tile_data).length > 0) { // skips tiles without properties
                landdata += "[tile." + tile.id + "]\n";

                for (var key in tile_data) {
                    var val = typeof tile_data[key] === "string"  ? "\"" + tile_data[key] + "\""
                            : typeof tile_data[key] === "number"  ? tile_data[key]
                            : typeof tile_data[key] === "boolean" ? tile_data[key]
                            : "";
                    landdata += key + " = " + val + "\n";
                }
            }
        }

        // .oldata for terrain
        if (landdata.length > 0) { // skips if no properties are set (= user wants to make .oldata manually)
            var landdataFile = new TextFile(baseDir + "/../tilesets/" + data_terrain, TextFile.WriteOnly); // writes .oldata in directory of tileset image
            landdataFile.write(landdata);
            landdataFile.commit();
        }
    },
}

tiled.registerMapFormat("of lands map", olmMapFormat)