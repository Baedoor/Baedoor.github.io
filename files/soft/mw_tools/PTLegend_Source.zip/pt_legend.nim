import std/strutils
import pixie

# type
#   Settings = object
#
# proc parseSettings(): Settings =
#   for line in lines "settings.txt":
#     let s = line.split(" : ")

#[ options (to be moved to external file and/or GUI) ]#
#------------------------------
# colours
let bg_col     = "e0dbd4"
let alt_col    = "a7aa98"
let header_col = "807e6f"
let descr_font = readFont("fonts/TitilliumWeb-Regular.ttf")
let sect_len      = 300
let sect_blck     = 27
let header_height = 40
let province_mode = true #[ ... ]#

# TODO
# - settings by .txt file
# - set per-province poi+faction image (e.g. Cyrodiil-only)     --- done!
#   - double sections recognised
# - set width for column - by "::" in title - [Cyrodiil :: 400] --- done!
# - formatting header text to center

# - making HR split by culture
# - Valenwood, Elsweyr, Summerset

type
  Section = object
    name:  string               # def: ""
    width: int                  # def: sect_len
    elms:  seq[(string, string)]
proc emptySection(name: string = ""): Section =
  if " :: " in name:
    let sep = name.split(" :: ")
    result.name  = sep[0]
    result.width = parseInt(sep[1])
  else: # default
    result.width = sect_len
    result.name  = name
  result.elms  = newSeq[(string, string)]()

proc parseFile(f_path: string): seq[Section] =
  var sec = emptySection()

  for line in lines f_path:
    if " : " in line: # adds new faction
      let faction = line.split(" : ")
      add(sec.elms, (faction[0], faction[1]))
    elif startsWith(line, "---"): # adds previous section and creates new one
      if sec.elms.len > 0:
        add(result, sec)
      sec = emptySection(line.replace("--- ", "").replace("---", ""))
  if sec.elms.len > 0:
    add(result, sec)

proc sectionHeight(s: seq[Section]): int =
  # returns length of biggest Section from sequence
  result = 0
  for section in s:
    if section.elms.len > result:
      result = section.elms.len

proc sectionsWidth(s: seq[Section]): int =
  for sec in s:
    result += sec.width

let parsed_pois     = parseFile("pois.txt")
let parsed_factions = parseFile("factions.txt")

# should be done later in pipeline, before that settings should be set
var factions = newImage(width  = sectionsWidth(parsed_factions),
                        height = sect_blck * sectionHeight(parsed_factions) + header_height)
var pois     = newImage(width  = sectionsWidth(parsed_pois),
                        height = sect_blck * sectionHeight(parsed_pois) + header_height)

block fill:
  fill(factions, parseHex(bg_col))
  fill(pois,     parseHex(bg_col))

  # POIS
  var
    poi_x = 0
    poi_y = 0
  for pis in parsed_pois:
    block sect_header:
      let ctx = newContext(pois)
      ctx.fillStyle = parseHex(header_col)
      fillRect(ctx,
               rect(
                    poi_x.float32,     poi_y.float32,
                    pis.width.float32, sect_blck.float32 * 1.5))
      descr_font.size = 30
      pois.fillText(descr_font,
                    pis.name,
                    translate(vec2(poi_x.float32 + 50.float32, poi_y.float32 - 5.0)))
      poi_y += header_height

    for poi in pis.elms:
      let poi_icon = readImage("pois/" & poi[0])
      block bg:
        let ctx = newContext(pois)
        ctx.fillStyle = parseHex(alt_col)
        fillRect(ctx,
                 rect(
                     poi_x.float32,     poi_y.float32,
                     sect_blck.float32, sect_blck.float32))
      draw(pois,
           poi_icon,
           translate(vec2(poi_x.float32, poi_y.float32)))

      block descr:
        descr_font.size = 20
        pois.fillText(descr_font,
                      poi[1],
                      translate(vec2(poi_x.float32 + 32.float32, poi_y.float32 - 3.0)))

      poi_y += sect_blck
    # resets for new section
    poi_y  = 0
    poi_x += pis.width

  # FACTIONS
  var
    fc_x = 0
    fc_y = 0
  for fcs in parsed_factions:
    block sect_header:
      let ctx = newContext(factions)
      ctx.fillStyle = parseHex(header_col)
      fillRect(ctx,
               rect(
                    fc_x.float32,      fc_y.float32,
                    fcs.width.float32, sect_blck.float32 * 1.5))
      descr_font.size = 30
      factions.fillText(descr_font,
                        fcs.name,
                        translate(vec2(fc_x.float32 + 50.float32, fc_y.float32 - 5.0)))
      fc_y += header_height

    for fc in fcs.elms:
      block bg:
        let ctx = newContext(factions)
        ctx.fillStyle = parseHex(alt_col)
        fillRect(ctx,
                 rect(
                     fc_x.float32,      fc_y.float32,
                     sect_blck.float32, sect_blck.float32))
        ctx.fillStyle = parseHex(fc[0])
        fillRect(ctx,
                 rect(
                     fc_x.float32      + 3, fc_y.float32      + 3,
                     sect_blck.float32 - 6, sect_blck.float32 - 6))
      block descr:
        descr_font.size = 20
        factions.fillText(descr_font,
                          fc[1],
                          translate(vec2(fc_x.float32 + 32.float32, fc_y.float32 - 3.0)))

      fc_y += sect_blck

    # resets for new section
    fc_y = 0
    fc_x += fcs.width

block save:
  writeFile(factions, "factions.png")
  writeFile(pois,     "pois.png")

if province_mode: # runs additional province-specific images that are stored in /provinces/ folder
  iterator getIntertwined(p_seq: seq[Section], f_seq: seq[Section]): (Section, Section) =
    for p in p_seq:
      for f in f_seq:
        if p.name == f.name:
          yield (p, f)

  for cat in getIntertwined(parsed_pois, parsed_factions):
    var img_out = newImage(width  = sectionsWidth(@[cat[0], cat[1]]),
                           height = sect_blck * sectionHeight(@[cat[0], cat[1]]) + header_height)
    fill(img_out, parseHex(bg_col))
    var
      cat_x = 0
      cat_y = 0

    block header:
      let ctx = newContext(img_out)
      ctx.fillStyle = parseHex(header_col)
      fillRect(ctx,
               rect(
                    cat_x.float32,                               cat_y.float32,
                    cat[0].width.float32 + cat[1].width.float32, sect_blck.float32 * 1.5))
      descr_font.size = 30
      img_out.fillText(descr_font,
                       cat[0].name, # should be the same on cat[1]
                       translate(vec2(cat_x.float32 + 50.float32, cat_y.float32 - 5.0)))
      cat_y += header_height

    block poi:
      for p in cat[0].elms:
        let poi_icon = readImage("pois/" & p[0])
        block bg:
          let ctx = newContext(img_out)
          ctx.fillStyle = parseHex(alt_col)
          fillRect(ctx,
                   rect(
                       cat_x.float32,     cat_y.float32,
                       sect_blck.float32, sect_blck.float32))
        draw(img_out,
             poi_icon,
             translate(vec2(cat_x.float32, cat_y.float32)))

        block descr:
          descr_font.size = 20
          img_out.fillText(descr_font,
                           p[1],
                           translate(vec2(cat_x.float32 + 32.float32, cat_y.float32 - 3.0)))

        cat_y += sect_blck

      cat_y = 0 + header_height
      cat_x += cat[0].width

    block fac:
      for f in cat[1].elms:
        block bg:
          let ctx = newContext(img_out)
          ctx.fillStyle = parseHex(alt_col)
          fillRect(ctx,
                   rect(
                       cat_x.float32,     cat_y.float32,
                       sect_blck.float32, sect_blck.float32))
          ctx.fillStyle = parseHex(f[0])
          fillRect(ctx,
                   rect(
                       cat_x.float32     + 3, cat_y.float32      + 3,
                       sect_blck.float32 - 6, sect_blck.float32 - 6))
        block descr:
          descr_font.size = 20
          img_out.fillText(descr_font,
                           f[1],
                           translate(vec2(cat_x.float32 + 32.float32, cat_y.float32 - 3.0)))

        cat_y += sect_blck

    writeFile(img_out, "provinces/" & cat[0].name & ".png")