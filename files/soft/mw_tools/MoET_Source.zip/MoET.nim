#[ MoET --- Morrowind Extended Toolkit --- ]#
# Made by Toma400
# License: CC-0

#----------------
import std/strutils
import std/math
import nigui

app.init()

# alias to make it cleaner for algorithm
proc f (t: string): float =
  return parseFloat(t)
proc f (t: int): float =
  return float(t)

let window = newWindow("MoET - by Toma400")

# basic window
let main                 = newLayoutContainer(Layout_Vertical)
let northmarker_line     = newLayoutContainer(Layout_Horizontal)
let northmarker_settings = newLayoutContainer(Layout_Vertical)

let interior_box       = newLayoutContainer(Layout_Vertical)
let interior_descr     = newLabel("Interior door rotation (Z)")
let interior_coord     = newTextBox("")
let exterior_box       = newLayoutContainer(Layout_Vertical)
let exterior_descr     = newLabel("Exterior door rotation (Z)")
let exterior_coord     = newTextBox("")
let northmarker_box    = newLayoutContainer(Layout_Vertical)
let northmarker_descr  = newLabel("Northmarker rotation (Z)")
let northmarker_output = newTextBox("")

let hlaalu_tick        = newCheckbox("Hlaalu building")
let hlaalu_descr_box   = newLayoutContainer(Layout_Horizontal)
let hlaalu_descr       = newLabel("If Hlaalu calculation still doesn't match, increase rotation by 90 until it matches")

block registry:
  window.width = 500
  window.height = 180
  window.add(main)
  northmarker_output.editable = false
  main.add(northmarker_line)
  main.add(northmarker_settings)
  interior_box.add(interior_descr)
  interior_box.add(interior_coord)
  exterior_box.add(exterior_descr)
  exterior_box.add(exterior_coord)
  northmarker_box.add(northmarker_descr)
  northmarker_box.add(northmarker_output)
  northmarker_line.add(exterior_box)
  northmarker_line.add(interior_box)
  northmarker_line.add(northmarker_box)
  northmarker_settings.add(hlaalu_tick)
  northmarker_settings.add(hlaalu_descr_box)
  hlaalu_descr_box.frame = newFrame("Tip")
  hlaalu_descr_box.add(hlaalu_descr)

proc calculate(interior: float, exterior: float, hlaalu: bool): float =
    result = (((360.f - exterior) mod 360.f) + ((interior + 180.f) mod 360.f)) mod 360.f
    if hlaalu:
      result = result + 90


interior_coord.onTextChange = proc (event: TextChangeEvent) =
    try:
      northmarker_output.text = $calculate(f(interior_coord.text), f(exterior_coord.text), hlaalu_tick.checked)
    except: discard
exterior_coord.onTextChange = proc (event: TextChangeEvent) =
    try:
      northmarker_output.text = $calculate(f(interior_coord.text), f(exterior_coord.text), hlaalu_tick.checked)
    except: discard
hlaalu_tick.onToggle = proc (event: ToggleEvent) =
    try:
      northmarker_output.text = $calculate(f(interior_coord.text), f(exterior_coord.text), hlaalu_tick.checked)
    except: discard

window.show()
app.run()