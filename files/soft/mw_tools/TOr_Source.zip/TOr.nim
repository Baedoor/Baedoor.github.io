import std/private/oscommon
import std/private/osdirs
import std/strformat
import std/strutils
import std/times
import std/os

#[ TOr --- Tamriel Orderer --- ]#
# Made by Toma400

var t = parseTime("2005-01-01T00:00", "yyyy-MM-dd'T'HH:mm", utc())
var m = "All files processed! Click Enter to exit the program."
let d = initDuration(days = 1)

let van = ["morrowind.esm", "tribunal.esm", "bloodmoon.esm"] # must be lowercase for future check
var pgs = newSeq[string]() # list of .esm/.esp files in Data Files (for lookups)

if dirExists("Data Files"):
  for pg in walkFiles("Data Files/*.es*"):
     pgs.add(pg.replace(r"Data Files\", ""))
else:
  echo "Application not in correct directory. Put TOr in main Morrowind folder."
  discard readLine(stdin); quit()

const instr = """
== Tamriel Orderer Guide ===
TOr works by listing all Morrowind plugins (.esm/.esp files) in an order you want
these to be ordered in game. The syntax for that is as follows:
- File1.esm
- AnotherFile.esp
Files must be proper names of plugins found in your "Data Files", however if app
doesn't find the file, it will skip it. File names do not need to match exact
capitalisation, e.g. if the file is "EXAMPLE.ESM", writing "example.esm" will work.
You can also use empty lines to categorise entries or include comments by starting
the line with "#", both will be skipped by the app.

The file needs to only contain entries, so remove all the text above before you
run the app again.
"""

if not fileExists("plugins_order.txt"):
  writeFile("plugins_order.txt", instr)
  echo "Configuration file was made. Follow instructions written in 'plugins_order.txt' and run the app again. Click enter to exit the app."
  discard readLine(stdin)
  quit()

let f = readFile("plugins_order.txt")

echo fmt"""
============================================
Tamriel Orderer
==================================v=0.2=====
Welcome in TOr, application to reorder your 
Morrowind plugins. Here is the order through
which you requested them to be sorted out:

{f}

If their order is not to your liking, write
'quit' and click enter to exit the app and
edit the 'plugins_order.txt' file.
Simply click enter to proceed.
"""
let cor = readLine(stdin)
if cor == "quit":
  quit()

var count = (0, 0) # successes / files processed

for entry in f.splitLines():
  try:
    if entry == "" or entry.startsWith("#"): # allows for non-intrusive separations or comments in file
      continue

    count[1] = count[1]+1
    var e = entry.strip(trailing=false, chars={'-', ' '})

    # check for file existing + set correct name for it
    var exists = 0
    for pg in pgs:
      if cmpIgnoreCase(pg, e) == 0:
        e = pg
        exists = 1
    if exists == 0:
      echo fmt"File {e} does not exist or has unsupported format. Skipping."
      continue

    if e.toLowerAscii() in van:
      count[1] = count[1]-1
      continue # skipping vanilla files
    echo fmt"Processing file: {e} | Timestamp: {t}"
    setLastModificationTime("Data Files/" & e, t)
    echo fmt"File {e} processed correctly!"
    count[0] = count[0]+1
    t += d
  except:
    m = fmt"Unsupported error happened. Here is stacktrace explaining the issue: {getCurrentExceptionMsg()}"
    break

echo "----------"
echo fmt"Files processed correctly: {count[0]}/{count[1]}"
echo m
discard readLine(stdin)
     